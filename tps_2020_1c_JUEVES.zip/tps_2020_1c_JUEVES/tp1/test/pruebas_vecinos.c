#include <stdio.h>
#include <stdlib.h>

extern int vecinos(unsigned char* matriz, unsigned int i, unsigned int j, unsigned int M, unsigned int N);

void chequear(int a, int b){
    if( a == b ){
        printf("OK \n");
    
    } else{
        printf("NOOK \n");
    }
}

int main(){
    unsigned int M = 20;
    unsigned int N = 20;
    unsigned char* m_prueba = malloc(sizeof(char) * M * N);
    for (unsigned int i = 0; i < M; i++) {
        for (unsigned int j = 0; j < N; j++) {
            *(m_prueba + i * N + j) = '1';
        }
    }
    
    /*   00 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19
   [0]   0  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1
   [1]   1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1
   [2]   1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1
   [3]   1  1  1  1  0  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1
   [4]   1  1  1  1  1  0  0  1  1  1  1  1  1  1  1  1  1  1  1  1
   [5]   1  1  1  1  0  0  1  1  1  1  1  1  1  1  1  1  1  1  1  1
   [6]   1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1
   [7]   1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1
   [8]   1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1
   [9]   1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1
   [10]  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1
   [11]  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1
   [12]  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1
   [13]  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1
   [14]  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1
   [15]  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1
   [16]  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1
   [17]  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1
   [18]  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1
   [19]  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  1  0
    */

    *(m_prueba + 2 *  N + 3)  = '0'; //(2,3)
    *(m_prueba + 4 *  N + 3)  = '0'; //(4,3)
    *(m_prueba + 4 *  N + 5)  = '0'; //(4,5)
    *(m_prueba + 5 *  N + 4)  = '0'; //(5,4)
    *(m_prueba + 6 *  N + 4)  = '0'; //(6,4)
    *(m_prueba + 5 *  N + 5)  = '0'; //(5,5)
    *(m_prueba + 0 *  N + 0)  = '0'; //(0,0)
    *(m_prueba + 19 * N + 19) = '0'; //(19,19)
    
    chequear( vecinos(m_prueba, 2, 3, M, N), 0 );
    chequear( vecinos(m_prueba, 4, 3, M, N), 1 );
    chequear( vecinos(m_prueba, 4, 5, M, N), 2 );
    chequear( vecinos(m_prueba, 5, 4, M, N), 4 );
    chequear( vecinos(m_prueba, 6, 4, M, N), 2 );
    chequear( vecinos(m_prueba, 5, 5, M, N), 3 );
    chequear( vecinos(m_prueba, 0, 0, M, N), 1 );
    chequear( vecinos(m_prueba, 19, 19, M, N), 1 );
    
    return 0;
}