#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>

// Memoria principal de 65 536 B.
const unsigned int MEM_SIZE = 65536;
unsigned char* main_mem;

const unsigned int BLOCK_SIZE = 128;
typedef struct block{
    unsigned int tag;
    bool v;
    unsigned long long lru_time;
    unsigned char* values;
} block_c;

// Cache 4-way set associative de 4096 B con bloques de 128 B
const unsigned int SET_NUM = 8;
const unsigned int BLOCKS_BY_SET = 4;
const unsigned int BLOCK_NUM = 32;   //SET_NUM * BLOCKS_BY_SET, 32 bloques
block_c* cache;

unsigned long long* hits;
unsigned long long* accesses;

// SECCIÓN BITS
const unsigned int BITS_DIR = 16;
const unsigned int BITS_OFFSET = 7; // para mapear los 128 B del bloque
const unsigned int BITS_INDEX = 3; // para mapear los 8 conjuntos
const unsigned int BITS_TAG = 6;   //BITS_DIR - (BITS_OFFSET + BITS_INDEX)

// CONSTANTES ÚTILES
const unsigned int AUX_INDEX = 896; // 000000 111 0000000
const unsigned int AUX_OFFSET = 127; // 000000 000 1111111
const unsigned int AUX_TAG = 64512;  // 111111 000 0000000
const unsigned int AUX_BLOCKNUM = 65408; //AUX_TAG + AUX_INDEX, 111111 111 0000000


// CÓDIGOS DE SALIDA
const int EXIT_OK = 0;
const int MEMORY_ERROR = 1;
const int INVALID_FILE = 2;

void init_mem() {
    main_mem = malloc( sizeof(char) * MEM_SIZE );

    if (!main_mem) {
        fprintf(stderr, "No se pudo asignar memoria. \n");
        exit(MEMORY_ERROR);
    }

    for(unsigned int i = 0; i < MEM_SIZE; i += 1){
        main_mem[i] = 0;         // NO es un bit 0, es un BYTE
    }
}

void end_mem() {
    free(main_mem);
}

void init() {
    cache = malloc( sizeof(block_c) * BLOCK_NUM );

    if (!cache) {
        fprintf(stderr, "No se pudo asignar memoria. \n");
        free(main_mem);
        exit(MEMORY_ERROR);
    }

    for(unsigned int i = 0; i < BLOCK_NUM; i += 1){
        cache[i].tag = 0;
        cache[i].v = 0;
        cache[i].lru_time = 0;
        cache[i].values = malloc( sizeof(char) * (BLOCK_SIZE) );

        if (!cache[i].values) {
            fprintf(stderr, "No se pudo asignar memoria. \n");
            for(unsigned int i2 = 0; i2 < i; i2 += 1){
                free(cache[i2].values);
            }

            free(main_mem);
            free(cache);
            exit(MEMORY_ERROR);
        }

        for(unsigned int j = 0; j < BLOCK_SIZE; j += 1){
            cache[i].values[j] = 0;
        }
    }

    hits = malloc( sizeof(unsigned long long) );
    if (!hits) {
        fprintf(stderr, "No se pudo asignar memoria. \n");
        for(unsigned int i = 0; i < BLOCK_NUM; i += 1){
            free(cache[i].values);
        }

        free(main_mem);
        free(cache);
        exit(MEMORY_ERROR);
    }
    (* hits) = 0;

    accesses = malloc( sizeof(unsigned long long) );
    if (!accesses) {
        fprintf(stderr, "No se pudo asignar memoria. \n");
        for(unsigned int i = 0; i < BLOCK_NUM; i += 1){
            free(cache[i].values);
        }

        free(hits);
        free(main_mem);
        free(cache);
        exit(MEMORY_ERROR);
    }
    (* accesses) = 0;
}

unsigned int get_tag(unsigned int address){
    return (address & AUX_TAG) >> (BITS_OFFSET + BITS_INDEX);
}

unsigned int get_offset(unsigned int address){
    return (address & AUX_OFFSET);
}

unsigned int find_set(unsigned int address){
    return (address & AUX_INDEX) >> BITS_OFFSET;
}

unsigned int select_oldest(unsigned int setnum){
    unsigned long long min = cache[setnum * BLOCKS_BY_SET].lru_time;
    unsigned int min_idx = setnum * BLOCKS_BY_SET;

    for(unsigned int i = ( (setnum * BLOCKS_BY_SET) + 1); i < ( (setnum + 1) * BLOCKS_BY_SET ); i += 1){
        if ( cache[i].lru_time < min ){
            min = cache[i].lru_time;
            min_idx = i;
        }
    }

    // Se espera que la vía sea relativa al conjunto
    return min_idx % BLOCKS_BY_SET;
}

int compare_tag(unsigned int tag, unsigned int set){
    for(unsigned int i = (set * BLOCKS_BY_SET); i < ( (set + 1) * BLOCKS_BY_SET ); i += 1){
        if ( ( cache[i].v == 1 ) && ( cache[i].tag == tag ) ){
            return (int) i;
        }
    }

    return -1;
}

// blocknum --> block address (tag + index) en valor absoluto.
// way es entre 0 y 3, set es entre 0 y 7.
// Se llama en un READ MISS
// No tiene casos borde porque me están diciendo dónde tengo que guardar
// el bloque.
void read_tocache(unsigned int blocknum, unsigned int way, unsigned int set){
    unsigned int address_init = blocknum << BITS_OFFSET ; // | blocknum | 0000000 |
    unsigned int address_end = address_init + AUX_OFFSET; // | blocknum | 1111111 |

    // Metadata
    unsigned int tag = get_tag(address_init);
    unsigned int block_num = (BLOCKS_BY_SET * set) + way;
    cache[block_num].tag = tag;
    cache[block_num].v = 1;
    cache[block_num].lru_time = *( accesses );

    // Información del bloque (a nivel de bytes)
    for(unsigned int j = address_init; j <= address_end; j += 1){
        cache[block_num].values[j - address_init] = main_mem[j];
    }
}

// Se sabe que ya está en caché para ejecutar la función.
// Se llama para preservar la INTEGRIDAD con memoria principal.
void write_tocache(unsigned int address, unsigned char value){
    unsigned int tag = get_tag(address);
    unsigned int set = find_set(address);

    int block_num = compare_tag(tag, set);

    if ( block_num >= 0 ){
        unsigned int offset = get_offset(address);
        cache[block_num].lru_time = *( accesses );
        cache[block_num].values[offset] = value;
        (* hits) += 1;
        printf("*W HIT*    ");
    }

    else{
        printf(" W MISS    ");
    }

}

int first_free_way(unsigned int set){
    for(unsigned int i = (set * BLOCKS_BY_SET); i < ( (set + 1) * BLOCKS_BY_SET ); i += 1){
        if ( cache[i].v == 0 ){
            // Se espera que sea el número de bloque relativo al conjunto
            return (int) (i % BLOCKS_BY_SET);
        }
    }

    return -1;
}

// WRITE NO ALLOCATE: si hay un read miss, se debe agregar a la caché
// CASO BORDE: conjunto lleno (LRU).
unsigned char read_byte(unsigned int address){
    // Se trata de leer de caché
    unsigned int tag = get_tag(address);
    unsigned int set = find_set(address);
    unsigned int offset = get_offset(address);

    int block_num = compare_tag(tag, set);
    (* accesses) += 1;

    if ( block_num >= 0 ){
        // Si está, se devuelve
        (* hits) += 1;
        cache[block_num].lru_time = *( accesses );
        printf("*R HIT*    ");
        return cache[block_num].values[offset];
    }

    printf(" R MISS    ");

    // Si no está en caché, se carga de memoria
    int way = first_free_way(set);

    if( way < 0 ){
        // Reemplazar el bloque más viejo del set
        way = (int) select_oldest(set);
    }

    // Como hay un read miss, se trae a caché todo el bloque
    read_tocache( (address & AUX_BLOCKNUM) >> BITS_OFFSET, (unsigned int) way, set );

    return main_mem[address];
}

// Escribir el bloque en memoria
// y en cache si es que se encuentra
void write_byte(unsigned int address, unsigned char value){
    (* accesses) += 1;
    write_tocache(address, value);
    main_mem[address] = value;
}

float get_miss_rate(){
    if( (* accesses) == 0){
        return 0;
    }

    // printf(" hits: %llu  acceses: %llu \n", *hits, *accesses);

    return  ( (float) 100 ) -                 \
            ( ( (float) (* hits) ) /          \
              ( ( (float) (* accesses) ) ) *  \
              ( (float) 100 )                 \
            );
}

void end(){
    for(unsigned int i = 0; i < BLOCK_NUM; i += 1){
        free( cache[i].values );
    }

    free( cache );
    free( accesses );
    free( hits );
}

bool check_int_bounds( char* token, unsigned int a, unsigned int b ){
    for( unsigned int i = 0; i < strlen(token); i += 1 ){
        if( !isdigit( token[i] ) ){
            return false;
        }
    }

    int v0 = atoi(token);

    if( v0 < 0 ){
        return false;
    }

    unsigned int v = (unsigned int) v0;

    if( !( (v >= a) && (v < b) ) ){
        return false;
    }

    return true;
}

bool check_file(char* file_str, bool execute){
    FILE* file;
    char line[256];
    char line_aux[256];

    if( !( file = fopen( file_str, "r" ) ) ){
        return false;
    }

    // Por cada línea del archivo
    while( fgets( line, sizeof(line), file ) ) {
        // Se va a modificar la línea para recorrerla, por eso la copia.
        strcpy( line_aux, line );

        // Se recorre cada valor separado por espacio de la línea (token).
        char *token = strtok( line_aux, " " );

        // Quitar '\n'
        token[ strcspn( token, "\n" ) ] = 0;

        // Análisis del primer token: indica el tipo de instrucción,
        // y por ende, el tipo de reestricción a considerar.

        // línea en blanco
        if( strcmp(token, "") == 0  ){
            if(execute){
                printf( " === Blanco ===\n" );
            }
        }

        else if( strcmp(token, "FLUSH") == 0 ) {
            if(execute){
                end();
                printf( " === Flush ===\n" );
                init();
            }
        }

        else if( strcmp(token, "MR") == 0 ){
            if(execute){
                printf( " Miss rate  %.0f%c \n", get_miss_rate(), '%' );
            }
        }

        else if( strcmp(token, "W") == 0 && execute ){
            unsigned int address = (unsigned int) atoi( strtok(NULL, " ") );
            unsigned char value = (unsigned char) atoi( strtok(NULL, " ") );
            write_byte(address, value);
            printf( " Escribir %d (0x%02x) en dir. %d (0x%04x) \n", value, value, address, address);
        }

        else if( strcmp(token, "W") == 0 && !execute ){
            // Próximo token
            token = strtok(NULL, " ");

            if( token[ strlen(token) - 1 ] != ',' ){
                fclose(file);
                return false;
            }

            token[ strlen(token) - 1 ] = 0;

            if( !check_int_bounds( token, 0, MEM_SIZE ) ){
                fclose(file);
                return false;
            }

            // Próximo token
            token = strtok(NULL, " ");

            // Quitar '\n'
            token[ strcspn( token, "\n" ) ] = 0;

            if( !check_int_bounds( token, 0, 256 ) ){
                fclose(file);
                return false;
            }
        }

        else if( strcmp(token, "R") == 0 && execute ){
            unsigned int address = (unsigned int) atoi( strtok(NULL, " ") );
            unsigned char value = read_byte(address);
            printf( " Leer %d (0x%02x) en dir. %d (0x%04x) \n", value, value, address, address);
        }

        else if( strcmp(token, "R") == 0 && !execute ){
            token = strtok(NULL, " ");

            // Quitar '\n'
            token[ strcspn( token, "\n" ) ] = 0;

            if( !check_int_bounds( token, 0, MEM_SIZE ) ){
                fclose(file);
                return false;
            }
        }

        else{
            printf("Comando inválido: %s\n", token);
            fclose(file);
            return false;
        }

        // No puede sobrar ningún caracter después del análisis
        token = strtok(NULL, " ");

        if(token){
            printf("Texto sobrante luego de comando: '%s'\n", token);
            fclose(file);
            return false;
        }

        // strok requiere que para las siguientes iteraciones los valores de
        // referencia sean los nulos agregados al string (por eso la copia).
        token = strtok(NULL, "");
    }

    fclose(file);
    return true;
}

int main(int argc, char *argv[]) {
    if( argc < 2 || !check_file( argv[1], false ) ){
        fprintf(stderr, "%s", "Archivo invalido.\n");
        return INVALID_FILE;
    }

    init_mem();
    init();
    check_file( argv[1], true );
    end();

    end_mem(main_mem);

    return EXIT_OK;
}
